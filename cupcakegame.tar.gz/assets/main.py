import pygame
import random
import asyncio

async def main():
    pygame.init()
    WIDTH = 1280
    HEIGHT = 600

    screen = pygame.display.set_mode((WIDTH, HEIGHT), pygame.SCALED)
    pygame.display.set_caption("Cupcake Collector")
    clock = pygame.time.Clock()

    BACKGROUND = (30, 30, 40)

    bg = pygame.image.load("assets/bg.png").convert_alpha()
    bg = pygame.transform.scale(bg, (WIDTH, HEIGHT))

    # Player Configuration
    player_right = pygame.image.load("assets/player_right.png").convert_alpha()
    player_right = pygame.transform.scale(player_right, (70, 225))

    player_left = pygame.image.load("assets/player.png").convert_alpha()
    player_left = pygame.transform.scale(player_left, (70, 225))

    player_image = player_right

    cupcake_image = pygame.image.load("assets/cupcake.png").convert_alpha()
    cupcake_image = pygame.transform.scale(cupcake_image, (70, 70))

    player_x = 50
    player_y = 100
    running = True

    player_dx = 0
    player_dy = 0
    gravity = 1.5
    friction = .95
    jump_speed = -18
    on_ground = False

    score = 0
    font = pygame.font.SysFont("couriernew", 20)

    platforms = [
        pygame.Rect(0, 525, WIDTH, 100),
        pygame.Rect(150, 450, 150, 20),
        pygame.Rect(300, 350, 70, 20),
        pygame.Rect(400, 255, 70, 20),
        pygame.Rect(540, 190, 100, 20),
        pygame.Rect(740, 190, 100, 20),
        
        pygame.Rect(1230, 430, 50, 20),
        pygame.Rect(1115, 350, 65, 20),
        pygame.Rect(1230, 240, 50, 20),
        ]

    plat = platforms[0]

    cupcakes = [
        pygame.Rect(150, 230, 70, 70),
        pygame.Rect(550, 450, 70, 70),
        pygame.Rect(570, 100, 70, 70),
        pygame.Rect(770, 100, 70, 70),
        pygame.Rect(970, 130, 70, 70),
        pygame.Rect(1210, 0, 70, 70),
        
        pygame.Rect(random.randint(0, WIDTH - 70), random.randint(70, HEIGHT - 75), 70, 70),
        pygame.Rect(random.randint(0, WIDTH - 70), random.randint(70, HEIGHT - 75), 70, 70),
        pygame.Rect(random.randint(0, WIDTH - 70), random.randint(70, HEIGHT - 75), 70, 70)
    ]

    screen.blit(player_image, (player_x, player_y))

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            # Capture Keystrokes
            keys = pygame.key.get_pressed()

            if event.type == pygame.KEYDOWN:
                if keys[pygame.K_LEFT]:
                    player_dx -= 4
                    player_image = player_left

                elif keys[pygame.K_RIGHT]:
                    player_dx += 4
                    player_image = player_right

                elif keys[pygame.K_UP] and on_ground:
                    player_dy = jump_speed
                    on_ground = False

        player_rect = pygame.Rect(player_x, player_y, 70, 225)
        
        if not on_ground:
            player_dy += gravity
            player_y += player_dy

        cont = True
        on_ground = False
        for platform in platforms:
            if not cont:
                break
            if player_rect.colliderect(platform) and player_y + 150 <= platform.top and player_dy > 0 and player_y != platform.top - 225:
                player_y = platform.top - 224
                player_dy = 0
                on_ground = True
                cont = False

        player_x += player_dx
        player_dx *= friction

        if player_y >= platforms[0].top - 225:
            player_y = platforms[0].top - 225
            player_dy = 0
            on_ground = True

        if player_x < 0:
            player_x = 0
        elif player_x > WIDTH - 70:
            player_x = WIDTH - 70
        
        player_rect = pygame.Rect(player_x, player_y, 70, 225)

        for cupcake in cupcakes:
            if player_rect.colliderect(cupcake):
                cupcakes.remove(cupcake)
                score += 1
        
        screen.blit(bg, (0, 0))

        for platform in platforms:
            pygame.draw.rect(
                screen,
                (134, 186, 218),
                platform
            )

        for cupcake in cupcakes:
            screen.blit(
                cupcake_image,
                (cupcake.x, cupcake.y)
            )

        if score == 9:
            text_surface = font.render("CLEAR! You live another day!", True, (134, 186, 218))
            pygame.draw.rect(screen, BACKGROUND, (10, 15, 375, 30))
        else:
            text_surface = font.render("Collect all 9 Prescripts; Prescripts Collected: " + str(score), True, (134, 186, 218))
            pygame.draw.rect(screen, BACKGROUND, (10, 10, 600, 40))
        
        screen.blit(text_surface, (20, 20))

        screen.blit(player_image, (player_x, player_y))

        pygame.display.flip()
        clock.tick(60)

        await asyncio.sleep(0)
pygame.quit()
asyncio.run(main())